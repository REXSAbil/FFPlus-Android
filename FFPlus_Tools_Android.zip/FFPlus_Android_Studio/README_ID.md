# FF+ Aim Toolkit — Android project

Proyek Android Studio (Kotlin + WebView) untuk pendamping latihan game. Ini adalah **source project**, bukan APK yang sudah dikompilasi.

## Fitur
- Pengaturan dan penyimpanan preset sensitivitas lokal (tidak mengubah nilai sensitivitas di dalam game).
- Aim Trainer 30 detik untuk latihan refleks dan akurasi.
- HUD Planner untuk pratinjau/menyimpan posisi tombol.
- Crosshair kustom: bentuk plus/titik/circle/cross, warna, ukuran, transparansi, serta overlay Android opsional. Android dapat membatasi overlay di beberapa game/perangkat. Izin “Tampil di atas aplikasi lain” diperlukan.
- Game Launcher: menampilkan aplikasi yang bisa diluncurkan menurut visibilitas paket Android, lalu membuka pilihan pengguna.
- Mode Ringan: checklist persiapan dan pintasan ke pengaturan aplikasi/layar. Tidak memaksa menghentikan aplikasi lain atau mengubah proses game.
- Status/izin Shizuku.
- Tools tambahan: generator preset sensitivitas awal berdasarkan model HP dan gaya bermain (heuristik, bukan hasil pengukuran/garansi headshot).
- Pengubah DPI via perintah `wm density` melalui Shizuku, dengan rentang aman aplikasi 120–800 dan opsi reset ke default. Perubahan DPI sistem dapat mengubah ukuran UI; catat kondisi awal dan gunakan dengan hati-hati.
- Panduan reboot manual. Aplikasi tidak memaksa restart karena Android membatasi kemampuan tersebut untuk aplikasi biasa.
- Workflow GitHub Actions untuk membangun APK debug.

## Cara build APK tanpa Android Studio di PC
1. Buat repository GitHub baru.
2. Unggah seluruh isi folder proyek ini ke root repository, termasuk folder tersembunyi `.github/workflows/`.
3. Buka tab **Actions** dan pilih workflow **Build FFPlus APK**.
4. Tekan **Run workflow** dan tunggu hingga job berhasil.
5. Buka run yang selesai, unduh artifact **FFPlus-debug-APK**, ekstrak ZIP artifact, lalu instal `app-debug.apk`.

## Catatan
- Workflow memerlukan koneksi internet di GitHub untuk mengunduh dependensi Gradle/Android SDK.
- APK debug adalah build untuk pengujian; Android mungkin menampilkan konfirmasi saat memasang APK dari luar Play Store.
- Crosshair overlay memerlukan izin khusus dan tidak dijamin muncul pada setiap game/perangkat. Buka FF+ kembali untuk menonaktifkan overlay.
- Aplikasi tidak menyediakan auto-aim, auto-headshot, anti-recoil, atau manipulasi game. Tidak ada cara untuk menjamin sensitivitas 0 tetap licin atau menaikkan performa di luar batas perangkat.
- Fitur pengubahan DPI membutuhkan Shizuku aktif dan izin diberikan. Jika perintah ditolak pada perangkat tertentu, gunakan Opsi developer Android dan kembalikan nilai sebelumnya.
- Generator sensitivitas memakai rentang awal umum berdasarkan merek/model yang dimasukkan; bukan database sensitivitas teruji untuk tiap model dan tidak menjamin “gacor” atau headshot. Terapkan nilainya secara manual di game.
