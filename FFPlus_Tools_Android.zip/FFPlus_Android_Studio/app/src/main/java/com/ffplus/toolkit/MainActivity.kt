package com.ffplus.toolkit

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var web: WebView
    private var crosshairView: TextView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null
    private val requestCode = 4207
    private val windowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, _ ->
        if (code == requestCode) runOnUiThread { refreshShizukuStatus() }
    }
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refreshShizukuStatus() } }
    private val binderDeadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refreshShizukuStatus() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 11, 18)
        window.navigationBarColor = Color.rgb(8, 11, 18)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 11, 18))
            setPadding(dp(12), dp(8), dp(12), dp(6))
        }
        val header = TextView(this).apply {
            text = "FF+ AIM TOOLKIT  /  ANDROID"
            textSize = 15f
            setTextColor(Color.rgb(197, 255, 61))
            gravity = Gravity.CENTER_VERTICAL
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(2), 0, dp(5))
        }
        root.addView(header, LinearLayout.LayoutParams(-1, dp(32)))
        status = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.rgb(214, 228, 239))
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setBackgroundColor(Color.rgb(18, 27, 39))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(36)))
        val request = TextView(this).apply {
            text = "SHIZUKU: PERIKSA / MINTA IZIN"
            textSize = 10f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(8, 11, 18))
            setBackgroundColor(Color.rgb(197, 255, 61))
            setOnClickListener { requestShizukuPermission() }
        }
        root.addView(request, LinearLayout.LayoutParams(-1, dp(36)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(8, 11, 18))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshShizukuStatus()
    }

    inner class AndroidBridge {
        @JavascriptInterface fun getLaunchableApps(): String {
            val result = JSONArray()
            try {
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val matches = packageManager.queryIntentActivities(intent, 0)
                    .filter { it.activityInfo.packageName != packageName }
                    .distinctBy { it.activityInfo.packageName }
                    .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
                for (item in matches) {
                    result.put(JSONObject().put("label", item.loadLabel(packageManager).toString())
                        .put("packageName", item.activityInfo.packageName))
                }
            } catch (_: Exception) { }
            return result.toString()
        }

        @JavascriptInterface fun launchApp(packageName: String): String {
            return try {
                if (packageName.isBlank() || packageName == this@MainActivity.packageName) return "Nama paket tidak valid."
                val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return "Aplikasi tidak memiliki aktivitas peluncuran."
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runOnUiThread { try { startActivity(intent) } catch (_: Exception) { } }
                "Membuka aplikasi: $packageName"
            } catch (_: Exception) { "Tidak dapat membuka aplikasi tersebut." }
        }

        @JavascriptInterface fun toggleCrosshair(configJson: String): String {
            return try {
                val config = JSONObject(configJson)
                runOnUiThread {
                    if (crosshairView != null) removeCrosshair() else {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                            startActivity(intent)
                        } else showCrosshair(config)
                    }
                }
                "Jika izin overlay sudah diberikan, tekan tombol lagi untuk menampilkan/menyembunyikan crosshair."
            } catch (_: Exception) { "Tidak dapat mengaktifkan crosshair overlay." }
        }

        @JavascriptInterface fun openAppSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
        }
        @JavascriptInterface fun openDisplaySettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        }

        @JavascriptInterface fun setDisplayDensity(dpi: Int): String {
            if (dpi !in 120..800) return "DPI harus di antara 120 dan 800."
            return runShizukuShell("wm density $dpi")
        }

        @JavascriptInterface fun resetDisplayDensity(): String = runShizukuShell("wm density reset")
    }

    private fun showCrosshair(config: JSONObject) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return
        removeCrosshair()
        val shape = config.optString("shape", "plus")
        val glyph = when (shape) { "dot" -> "•"; "circle" -> "⊙"; "cross" -> "✛"; else -> "+" }
        val color = try { Color.parseColor(config.optString("color", "#39ff88")) } catch (_: Exception) { Color.GREEN }
        val size = config.optInt("size", 32).coerceIn(12, 60)
        val alpha = config.optInt("alpha", 100).coerceIn(20, 100) / 100f
        val view = TextView(this).apply {
            text = glyph
            textSize = size.toFloat()
            setTextColor(color)
            this.alpha = alpha
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(dp(4).toFloat(), 0f, 0f, color)
            contentDescription = "FF+ custom crosshair; tap FF+ app to turn off"
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER; x = 0; y = 0 }
        try {
            windowManager.addView(view, params)
            crosshairView = view
            crosshairParams = params
        } catch (_: Exception) { }
    }

    private fun removeCrosshair() {
        try { crosshairView?.let { windowManager.removeView(it) } } catch (_: Exception) { }
        crosshairView = null
        crosshairParams = null
    }

    private fun runShizukuShell(command: String): String {
        return try {
            if (Shizuku.getBinder() == null) return "Shizuku belum aktif. Buka Shizuku dan mulai layanan terlebih dahulu."
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                return "Izin Shizuku belum diberikan. Tekan tombol Shizuku di bagian atas aplikasi."
            }
            // Only commands generated by the two fixed DPI actions are allowed.
            if (!command.matches(Regex("wm density (reset|[0-9]{3})"))) return "Perintah tidak diizinkan."
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
            val exit = process.waitFor()
            val output = (stdout + "\n" + stderr).trim()
            if (exit == 0) "Perintah DPI berhasil dijalankan. $output" else "Perintah DPI gagal (kode $exit). $output"
        } catch (e: Exception) {
            "Gagal mengubah DPI lewat Shizuku: ${e.javaClass.simpleName}. Gunakan Opsi developer untuk mengembalikan nilai jika perlu."
        }
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.isPreV11()) { status.text = "Versi Shizuku terlalu lama. Perbarui Shizuku lalu coba lagi."; return }
            if (Shizuku.getBinder() == null) { status.text = "Shizuku belum berjalan. Buka aplikasi Shizuku dan mulai layanan terlebih dahulu."; return }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                status.text = "Shizuku terhubung · izin aplikasi sudah diberikan."
            } else Shizuku.requestPermission(requestCode)
        } catch (e: Exception) { status.text = "Status Shizuku tidak tersedia: ${e.javaClass.simpleName}" }
    }

    private fun refreshShizukuStatus() {
        try {
            status.text = when {
                Shizuku.getBinder() == null -> "SHIZUKU: OFFLINE · layanan tidak aktif (fitur lain tetap bisa dipakai)."
                Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED -> "SHIZUKU: TERHUBUNG · izin diberikan."
                else -> "SHIZUKU: TERDETEKSI · izin belum diberikan."
            }
        } catch (_: Exception) { status.text = "SHIZUKU: BELUM TERSEDIA · periksa aplikasi Shizuku." }
    }

    override fun onDestroy() {
        removeCrosshair()
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        web.removeJavascriptInterface("AndroidBridge")
        web.destroy()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
